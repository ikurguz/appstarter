<?php


namespace App\Controllers;


use CodeIgniter\Exceptions\PageNotFoundException;

class Blog extends BaseController
{

    public function index()
    {
        $data = [
            'title' => 'Блог',
            'posts' => [
                [
                    'slug' => 'post-1',
                    'title' => 'Post 1',
                    'text' => '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid dolores dolorum eius eos eveniet, ipsa labore nisi odit quas repellat sint soluta tempora totam vitae voluptates! Aliquam, doloribus eos. Facilis.</p>',
                ],
                [
                    'slug' => 'post-2',
                    'title' => 'Post 2',
                    'text' => '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid dolores dolorum eius eos eveniet, ipsa labore nisi odit quas repellat sint soluta tempora totam vitae voluptates! Aliquam, doloribus eos. Facilis.</p>',
                ],
                [
                    'slug' => 'post-3',
                    'title' => 'Post 3',
                    'text' => '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid dolores dolorum eius eos eveniet, ipsa labore nisi odit quas repellat sint soluta tempora totam vitae voluptates! Aliquam, doloribus eos. Facilis.</p>',
                ],
            ],
        ];
        return view('blog/index', $data);
    }

    public function view($slug)
    {
        $posts = [
            [
                'slug' => 'post-1',
                'title' => 'Post 1',
                'text' => '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid dolores dolorum eius eos eveniet, ipsa labore nisi odit quas repellat sint soluta tempora totam vitae voluptates! Aliquam, doloribus eos. Facilis.</p>',
            ],
            [
                'slug' => 'post-2',
                'title' => 'Post 2',
                'text' => '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid dolores dolorum eius eos eveniet, ipsa labore nisi odit quas repellat sint soluta tempora totam vitae voluptates! Aliquam, doloribus eos. Facilis.</p>',
            ],
            [
                'slug' => 'post-3',
                'title' => 'Post 3',
                'text' => '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid dolores dolorum eius eos eveniet, ipsa labore nisi odit quas repellat sint soluta tempora totam vitae voluptates! Aliquam, doloribus eos. Facilis.</p>',
            ],
        ];

        $post = array_search($slug, array_column($posts, 'slug'));
        if (false === $post) {
            throw PageNotFoundException::forPageNotFound();
        }

        $data = [
            'title' => 'Статья',
            'post' => $posts[$post],
        ];

        return view('blog/view', $data);
    }

}