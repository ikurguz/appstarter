<div class="col-12">
    <div class="card">
        <img src="https://picsum.photos/id/1045/400/400" class="card-img-top card-img" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?= $post['title'] ?></h5>
            <p class="card-text"><?= $post['text'] ?></p>
        </div>
    </div>
</div>
