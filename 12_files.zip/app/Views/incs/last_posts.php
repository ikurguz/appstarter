<?php foreach ($posts as $post): ?>
    <p><?= $post ?></p>
<?php endforeach; ?>
