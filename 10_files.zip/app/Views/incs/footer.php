<?= view_cell('\App\Libraries\Post::lastPosts', 'limit=3') ?>

</body>
</html>
