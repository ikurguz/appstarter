<article class="article">
    <h3><a href="/blog/<?= $post['slug'] ?>"><?= $post['title'] ?></a></h3>
    <?= $post['text'] ?>
</article>