<?= $this->extend('layouts/test') ?>

<?= $this->section('content') ?>
    <h1><?= $title ?></h1>

    <?= view_cell('\App\Libraries\Post::getPost', ['post' => $post]) ?>
<?= $this->endSection() ?>

