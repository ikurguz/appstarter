<?= $this->extend('layouts/default') ?>

<?= $this->section('content') ?>
    <h1><?= $title ?></h1>

    <?php foreach ($posts as $post): ?>
        <?= view_cell('\App\Libraries\Post::getPost', ['post' => $post]) ?>
        <hr>
    <?php endforeach; ?>
<?= $this->endSection() ?>
