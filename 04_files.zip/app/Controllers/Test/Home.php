<?php


namespace App\Controllers\Test;


use App\Controllers\BaseController;

class Home extends BaseController
{

    public function index()
    {
        echo __METHOD__;
    }

}