<?php


namespace App\Controllers\Shop;


use App\Controllers\BaseController;

class Product extends BaseController
{

    public function index()
    {
        echo "<h1>Hello, Shop!</h1>";
    }

    public function show($name, $id)
    {
        echo "<h1>Product: {$name} {$id}</h1>";
    }

}